export const constants = {
    baseUrl: `https://flutterapi.testdevlink.net/elite-care-db/`
}