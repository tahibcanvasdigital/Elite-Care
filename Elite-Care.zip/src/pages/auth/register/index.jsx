import React from "react";
import styles from "./style.module.css";
const Register = () => {
  return <div>Register</div>;
};

export default Register;
